### REDDIT RANDOM HOTKEY
This is a pretty basic Firefox extension that allows you to use **Alt+Shift+X** to go to a random subreddit, instead of having to click the tiny **RANDOM** button.  It saves a little bit of time, especially when subs with custom CSS move the button around and you end up spending more time moving your mouse around than cycling through content.  It's the same binding as the **Random article** hotkey on Wikipedia.
I primarily made this for fun and for my own use, there's already a pretty comprehensive extension for Reddit hotkeys.
